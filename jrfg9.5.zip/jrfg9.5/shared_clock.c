#include "shared_clock.h"
#include "config.h"
#include <sys/ipc.h>
#include <sys/shm.h>
#include <stdlib.h>
#include <stdio.h>

static int shmid = -1;

int createClock() {
    shmid = shmget(SHMKEY_CLOCK, sizeof(SharedClock), IPC_CREAT | 0666);
    if (shmid == -1) {
        perror("shmget failed");
        exit(1);
    }
    return shmid;
}

SharedClock* attachClock() {
    if (shmid == -1) {
        shmid = shmget(SHMKEY_CLOCK, sizeof(SharedClock), 0666);
        if (shmid == -1) {
            perror("shmget failed");
            exit(1);
        }
    }
    SharedClock* clk = (SharedClock*) shmat(shmid, NULL, 0);
    if (clk == (void*) -1) {
        perror("shmat failed");
        exit(1);
    }
    return clk;
}

void incrementClock(SharedClock* clk, unsigned int ns) {
    clk->nanoseconds += ns;
    while (clk->nanoseconds >= BILLION) {
        clk->seconds += 1;
        clk->nanoseconds -= BILLION;
    }
}

void detachClock(SharedClock* clk) {
    if (shmdt(clk) == -1) {
        perror("shmdt failed");
        exit(1);
    }
}

void destroyClock() {
    if (shmctl(shmid, IPC_RMID, NULL) == -1) {
        perror("shmctl failed");
        exit(1);
    }
}