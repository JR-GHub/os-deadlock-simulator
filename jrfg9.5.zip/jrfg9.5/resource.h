#ifndef RESOURCE_H
#define RESOURCE_H

#include "config.h"

typedef struct {
    int available;                     // Available instances
    int total;                         // Total instances
    int allocation[MAX_PROCESSES];    // Allocation per process
    int request[MAX_PROCESSES];       // Pending requests per process
    int waitQueue[MAX_QUEUE];         // Process IDs waiting
    int queueSize;
} ResourceDescriptor;

void initResources(ResourceDescriptor resources[MAX_RESOURCES]);
int canGrant(int pid, int resIndex, int amount, ResourceDescriptor resources[]);
void grantResource(int pid, int resIndex, int amount, ResourceDescriptor resources[]);
void releaseResource(int pid, int resIndex, int amount, ResourceDescriptor resources[]);
void releaseAllResources(int pid, ResourceDescriptor resources[]);

#endif