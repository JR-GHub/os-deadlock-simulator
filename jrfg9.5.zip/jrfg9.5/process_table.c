#include "process_table.h"
#include "config.h"
#include <string.h>

/*
 * initProcessTable:
 *   Initializes the process table, marking all entries as free.
 */
void initProcessTable(PCB table[MAX_PROCESSES]) {
    for (int i = 0; i < MAX_PROCESSES; i++) {
        table[i].occupied = 0;
        table[i].pid = 0;
        memset(table[i].totalAllocated, 0, sizeof(int) * MAX_RESOURCES);
        memset(table[i].totalRequested, 0, sizeof(int) * MAX_RESOURCES);
    }
}

/*
 * getAvailableIndex:
 *   Returns the index of the first free PCB slot, or -1 if none available.
 */
int getAvailableIndex(PCB table[MAX_PROCESSES]) {
    for (int i = 0; i < MAX_PROCESSES; i++) {
        if (!table[i].occupied) {
            return i;
        }
    }
    return -1;
}

/*
 * findPCBIndexByPID:
 *   Returns the index of the PCB matching the given pid, or -1 if not found.
 */
int findPCBIndexByPID(PCB table[MAX_PROCESSES], pid_t pid) {
    for (int i = 0; i < MAX_PROCESSES; i++) {
        if (table[i].occupied && table[i].pid == pid) {
            return i;
        }
    }
    return -1;
}
