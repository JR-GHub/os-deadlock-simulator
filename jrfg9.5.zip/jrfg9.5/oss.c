// oss.c
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <signal.h>
#include <getopt.h>
#include <time.h>

#include "config.h"
#include "shared_clock.h"
#include "resource.h"
#include "process_table.h"
#include "msgqueue.h"
#include "token.h"
#include "logger.h"
#include "deadlock.h"

#define CLOCK_INCREMENT_NS 1000000UL  // 1 ms simulated increment

int main(int argc, char *argv[]) {
    int maxTotal = MAX_TOTAL_PROCESSES;
    int simTimeLimit = 5;            // real-time seconds to allow spawning
    int launchIntervalMs = 1000;     // ms between child launches
    char *logFile = "oss.log";

    int opt;
    while ((opt = getopt(argc, argv, "hn:s:i:f:")) != -1) {
        switch (opt) {
        case 'h':
            printf("Usage: %s [-n maxTotal] [-s simTimeLimit] [-i launchIntervalMs] [-f logFile]\n", argv[0]);
            exit(EXIT_SUCCESS);
        case 'n':
            maxTotal = atoi(optarg);
            break;
        case 's':
            simTimeLimit = atoi(optarg);
            break;
        case 'i':
            launchIntervalMs = atoi(optarg);
            break;
        case 'f':
            logFile = optarg;
            break;
        default:
            fprintf(stderr, "Unknown option -%c\n", opt);
            exit(EXIT_FAILURE);
        }
    }

    initLogger(logFile, VERBOSE);

    createClock();
    SharedClock *clk = attachClock();
    clk->seconds = 0;
    clk->nanoseconds = 0;

    int msqid = createMsgQueue();

    ResourceDescriptor resources[MAX_RESOURCES];
    initResources(resources);

    PCB table[MAX_PROCESSES];
    initProcessTable(table);

    int deadlocked[MAX_PROCESSES];

    unsigned long launchIntervalNs = launchIntervalMs * 1000000UL;
    unsigned long lastLaunchTime = 0;
    unsigned long lastLogTime = 0;
    unsigned int lastDeadlockSec = 0;
    unsigned int startReal = time(NULL);

    int totalGenerated = 0;
    int activeCount = 0;

    int totalRequests = 0;
    int immediateGranted = 0;
    int delayedRequests = 0;
    int deadlockDetections = 0;
    int processesKilledByDeadlock = 0;
    int processesTerminatedNormally = 0;

    while (((totalGenerated < maxTotal) && ((time(NULL) - startReal) < simTimeLimit)) || (activeCount > 0)) {
        // Advance simulated clock and throttle to real time
        incrementClock(clk, CLOCK_INCREMENT_NS);
        usleep(1000);  // sleep 1ms real time per 1ms simulated

        unsigned long simTime = clk->seconds * BILLION + clk->nanoseconds;

        // Fork new child if allowed
        if (totalGenerated < maxTotal && activeCount < MAX_PROCESSES
            && (simTime - lastLaunchTime) >= launchIntervalNs) {
            pid_t pid = fork();
            if (pid < 0) {
                perror("fork");
            } else if (pid == 0) {
                char bStr[32];
                snprintf(bStr, sizeof(bStr), "%d", BILLION);
                execl("./user_proc", "user_proc", bStr, NULL);
                perror("execl user_proc");
                exit(EXIT_FAILURE);
            } else {
                int idx = getAvailableIndex(table);
                if (idx >= 0) {
                    table[idx].occupied = 1;
                    table[idx].pid = pid;
                    totalGenerated++;
                    activeCount++;
                    lastLaunchTime = simTime;
                    logLine("Master created P%d at time %u:%u", pid, clk->seconds, clk->nanoseconds);
                }
            }
        }

        // Reap any exited children
        {
            int status;
            pid_t wpid;
            while ((wpid = waitpid(-1, &status, WNOHANG)) > 0) {
                int idx = findPCBIndexByPID(table, wpid);
                if (idx >= 0) {
                    releaseAllResources(idx, resources);
                    table[idx].occupied = 0;
                    activeCount--;
                    processesTerminatedNormally++;
                    logLine("Master: P%d terminated normally at time %u:%u", wpid, clk->seconds, clk->nanoseconds);
                }
            }
        }

        // Handle incoming messages
        {
            Message msg;
            while (recvMsg(msqid, &msg, 1, IPC_NOWAIT) == 0) {
                pid_t rpid = msg.pid;            // real OS PID
                int rID = msg.resourceID;
                int idx = findPCBIndexByPID(table, rpid);
                if (idx < 0) continue;           // unknown PID

                switch (msg.op) {
                case MSG_TYPE_REQUEST:
                    totalRequests++;
                    if (canGrant(idx, rID, msg.amount, resources)) {
                        grantResource(idx, rID, msg.amount, resources);
                        immediateGranted++;
                        logLine("Master granting P%d request R%d at time %u:%u", rpid, rID, clk->seconds, clk->nanoseconds);
                        Message grantMsg;
                        initMessage(&grantMsg, rpid, MSG_TYPE_GRANTED, rID, msg.amount, getpid());
                        sendMsg(msqid, &grantMsg);
                    } else {
                        delayedRequests++;
                        resources[rID].request[idx] = msg.amount;
                        if (resources[rID].queueSize < MAX_QUEUE) {
                            resources[rID].waitQueue[resources[rID].queueSize++] = rpid;
                        }
                        logLine("Master: no instances of R%d, P%d queued at time %u:%u", rID, rpid, clk->seconds, clk->nanoseconds);
                    }
                    break;

                case MSG_TYPE_RELEASE:
                    releaseResource(idx, rID, msg.amount, resources);
                    logLine("Master acknowledged P%d releasing R%d at time %u:%u", rpid, rID, clk->seconds, clk->nanoseconds);
                    // Try to satisfy queued requests
                    for (int q = 0; q < resources[rID].queueSize; q++) {
                        pid_t qpid = resources[rID].waitQueue[q];
                        int qidx = findPCBIndexByPID(table, qpid);
                        if (qidx >= 0 && canGrant(qidx, rID, 1, resources)) {
                            grantResource(qidx, rID, 1, resources);
                            Message grantMsg;
                            initMessage(&grantMsg, qpid, MSG_TYPE_GRANTED, rID, 1, getpid());
                            sendMsg(msqid, &grantMsg);
                            logLine("Master granting queued P%d request R%d at time %u:%u", qpid, rID, clk->seconds, clk->nanoseconds);
                        }
                    }
                    break;

                case MSG_TYPE_TERMINATE:
                    releaseAllResources(idx, resources);
                    table[idx].occupied = 0;
                    activeCount--;
                    processesTerminatedNormally++;
                    logLine("Master: P%d terminated itself at time %u:%u", rpid, clk->seconds, clk->nanoseconds);
                    break;
                }
            }
        }

        // Periodic logging every 0.5s simulated
        if ((clk->seconds * BILLION + clk->nanoseconds - lastLogTime) >= (BILLION / 2)) {
            lastLogTime = clk->seconds * BILLION + clk->nanoseconds;
            logLine("System Resources at %u:%u", clk->seconds, clk->nanoseconds);
            for (int r = 0; r < MAX_RESOURCES; r++) {
                logLine("R%d: %d/%d", r, resources[r].available, resources[r].total);
            }
            logLine("Process Table:");
            for (int p = 0; p < MAX_PROCESSES; p++) {
                if (table[p].occupied) {
                    logLine("P%d PID=%d", p, table[p].pid);
                }
            }
        }

        // Deadlock detection every 1s simulated
        if (clk->seconds > lastDeadlockSec) {
            deadlockDetections++;
            lastDeadlockSec = clk->seconds;
            int count = detectDeadlock(resources, table, deadlocked);
            if (count > 0) {
                logLine("Deadlock detected at %u:%u (%d procs)", clk->seconds, clk->nanoseconds, count);
                while ((count = detectDeadlock(resources, table, deadlocked)) > 0) {
                    // choose victim holding most resources
                    int victim = deadlocked[0], maxAlloc = -1;
                    for (int d = 0; d < count; d++) {
                        int i = deadlocked[d], sum = 0;
                        for (int rr = 0; rr < MAX_RESOURCES; rr++) {
                            sum += resources[rr].allocation[i];
                        }
                        if (sum > maxAlloc) { maxAlloc = sum; victim = i; }
                    }
                    pid_t vpid = table[victim].pid;
                    kill(vpid, SIGTERM);
                    releaseAllResources(victim, resources);
                    table[victim].occupied = 0;
                    processesKilledByDeadlock++;
                    activeCount--;
                    logLine("Master terminating P%d to resolve deadlock at %u:%u", vpid, clk->seconds, clk->nanoseconds);
                }
            }
        }
    }

    // Final summary
    logLine("Simulation ended at %u:%u", clk->seconds, clk->nanoseconds);
    logLine("Total requests: %d (immediate=%d, delayed=%d)", totalRequests, immediateGranted, delayedRequests);
    logLine("Deadlock detections: %d, killed: %d", deadlockDetections, processesKilledByDeadlock);
    logLine("Processes terminated normally: %d", processesTerminatedNormally);

    destroyClock();
    destroyMsgQueue(msqid);
    closeLogger();
    return 0;
}