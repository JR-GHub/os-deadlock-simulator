

#include "config.h"

// Configuration constants are defined in config.h.
// No additional implementation is required in this file.