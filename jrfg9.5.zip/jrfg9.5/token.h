// token.h
#ifndef TOKEN_H
#define TOKEN_H

#include <sys/types.h>

#define MSG_TYPE_REQUEST   1
#define MSG_TYPE_RELEASE   2
#define MSG_TYPE_TERMINATE 3
#define MSG_TYPE_GRANTED   4

typedef struct {
    long  mtype;       // msg type (e.g., pid)
    int   op;          // MSG_TYPE_*
    int   resourceID;  // which resource
    int   amount;      // how many instances
    pid_t pid;         // sender PID
} Message;

// Initialize a Message struct
void initMessage(Message* msg, long mtype, int op, int resourceID, int amount, pid_t pid);

// (Optional) Debug helper to print a Message
void printMessage(const Message* msg);

#endif