#ifndef LOGGER_H
#define LOGGER_H

#include <stdio.h>
#include "config.h"

void initLogger(const char* filename, int verbose);
void logLine(const char* format, ...);
void flushLogger();
void closeLogger();
int getLogCount();

#endif