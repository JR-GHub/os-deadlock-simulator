#include "deadlock.h"
#include <signal.h>
#include <stdlib.h>

/*
 * detectDeadlock:
 *   Returns count of deadlocked PCBs (indices in 'deadlocked' array).
 */
int detectDeadlock(ResourceDescriptor resources[MAX_RESOURCES],
                   PCB table[MAX_PROCESSES],
                   int *deadlocked) {
    int work[MAX_RESOURCES], finish[MAX_PROCESSES];
    int n = MAX_PROCESSES, m = MAX_RESOURCES, countDead = 0;

    for (int j = 0; j < m; j++)
        work[j] = resources[j].available;

    for (int i = 0; i < n; i++) {
        if (!table[i].occupied) finish[i] = 1;
        else {
            int pending = 0;
            for (int j = 0; j < m; j++)
                if (resources[j].request[i] > 0) { pending = 1; break; }
            finish[i] = (pending == 0);
        }
    }

    int changed;
    do {
        changed = 0;
        for (int i = 0; i < n; i++) {
            if (!finish[i]) {
                int ok = 1;
                for (int j = 0; j < m; j++)
                    if (resources[j].request[i] > work[j]) { ok = 0; break; }
                if (ok) {
                    for (int j = 0; j < m; j++)
                        work[j] += resources[j].allocation[i];
                    finish[i] = 1;
                    changed = 1;
                }
            }
        }
    } while (changed);

    for (int i = 0; i < n; i++)
        if (table[i].occupied && !finish[i])
            deadlocked[countDead++] = i;

    return countDead;
}

/*
 * resolveDeadlock:
 *   Selects victim holding most resources, SIGTERMs it, frees its allocations.
 */
int resolveDeadlock(ResourceDescriptor resources[MAX_RESOURCES],
                    PCB table[MAX_PROCESSES],
                    int *deadlocked,
                    int count) {
    if (count <= 0) return 0;

    int victim = deadlocked[0], maxAlloc = -1;
    for (int k = 0; k < count; k++) {
        int idx = deadlocked[k], sum = 0;
        for (int j = 0; j < MAX_RESOURCES; j++)
            sum += resources[j].allocation[idx];
        if (sum > maxAlloc) { maxAlloc = sum; victim = idx; }
    }

    pid_t pidToKill = table[victim].pid;
    kill(pidToKill, SIGTERM);

    for (int j = 0; j < MAX_RESOURCES; j++) {
        int amt = resources[j].allocation[victim];
        if (amt > 0) {
            resources[j].available += amt;
            resources[j].allocation[victim] = 0;
        }
        resources[j].request[victim] = 0;
    }
    table[victim].occupied = 0;
    return 1;
}