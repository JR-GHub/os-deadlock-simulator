// user_proc.c
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include <sys/types.h>
#include "shared_clock.h"
#include "config.h"
#include "msgqueue.h"
#include "token.h"

#define REQUEST_PROB 70  // Percentage probability to request vs release

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <bound B in ns>\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    int B = atoi(argv[1]);
    if (B <= 0) {
        fprintf(stderr, "Bound B must be positive\n");
        exit(EXIT_FAILURE);
    }

    SharedClock *clk = attachClock();
    int msqid = createMsgQueue();
    pid_t pid = getpid();
    srand((unsigned int)(pid ^ clk->nanoseconds));

    unsigned int startSec = clk->seconds;
    unsigned int startNs = clk->nanoseconds;
    unsigned long killThreshold = BILLION + (rand() % BILLION);

    int held[MAX_RESOURCES] = {0};

    while (1) {
        unsigned long curElapsed =
            (clk->seconds - startSec) * BILLION +
            (clk->nanoseconds - startNs);

        if (curElapsed >= killThreshold) {
            Message msg;
            // release all held resources
            for (int i = 0; i < MAX_RESOURCES; i++) {
                while (held[i] > 0) {
                    initMessage(&msg, 1, MSG_TYPE_RELEASE, i, 1, pid);
                    sendMsg(msqid, &msg);
                    held[i]--;
                }
            }
            // notify OSS of termination
            initMessage(&msg, 1, MSG_TYPE_TERMINATE, 0, 0, pid);
            sendMsg(msqid, &msg);
            detachClock(clk);
            exit(EXIT_SUCCESS);
        }

        // random action trigger
        int r = rand() % (B + 1);
        if ((unsigned long)r <= curElapsed) {
            Message msg;
            if ((rand() % 100) < REQUEST_PROB) {
                // request a resource
                int res = rand() % MAX_RESOURCES;
                initMessage(&msg, 1, MSG_TYPE_REQUEST, res, 1, pid);
                sendMsg(msqid, &msg);
                // wait for grant
                Message resp;
                recvMsg(msqid, &resp, pid, 0);
                if (resp.op == MSG_TYPE_GRANTED) {
                    held[res]++;
                }
            } else {
                // release one held instance
                int candidates[MAX_RESOURCES], count = 0;
                for (int i = 0; i < MAX_RESOURCES; i++) {
                    if (held[i] > 0) {
                        candidates[count++] = i;
                    }
                }
                if (count > 0) {
                    int idx = candidates[rand() % count];
                    initMessage(&msg, 1, MSG_TYPE_RELEASE, idx, 1, pid);
                    sendMsg(msqid, &msg);
                    held[idx]--;
                }
            }
            // reset action timer
            startSec = clk->seconds;
            startNs = clk->nanoseconds;
        }

        // small sleep to reduce busy spinning
        usleep(1000);
    }

    return 0;
}