#include "logger.h"
#include <stdarg.h>
#include <stdlib.h>

static FILE *log_fp = NULL;
static int verboseFlag = 0;
static int logCount = 0;

void initLogger(const char* filename, int verbose) {
    if (log_fp != NULL) {
        return;  // already initialized
    }
    log_fp = fopen(filename, "w");
    if (!log_fp) {
        perror("Failed to open log file");
        exit(EXIT_FAILURE);
    }
    verboseFlag = verbose;
    logCount = 0;
}

void logLine(const char* format, ...) {
    if (!log_fp || logCount >= MAX_LOG_LINES) return;

    va_list args;
    va_start(args, format);
    vfprintf(log_fp, format, args);
    fprintf(log_fp, "\n");
    va_end(args);

    if (verboseFlag) {
        va_list args2;
        va_start(args2, format);
        vfprintf(stdout, format, args2);
        printf("\n");
        va_end(args2);
    }
    logCount++;
}

void flushLogger() {
    if (log_fp) fflush(log_fp);
    if (verboseFlag) fflush(stdout);
}

void closeLogger() {
    if (log_fp) {
        fclose(log_fp);
        log_fp = NULL;
    }
}

int getLogCount() {
    return logCount;
}