#include "msgqueue.h"
#include "config.h"
#include <sys/ipc.h>
#include <sys/msg.h>
#include <stdio.h>
#include <stdlib.h>

/*
 * createMsgQueue:
 *   Creates or gets a System V message queue using MSGKEY.
 *   Exits on failure.
 */
int createMsgQueue() {
    int msqid = msgget(MSGKEY, IPC_CREAT | 0666);
    if (msqid == -1) {
        perror("msgget failed");
        exit(EXIT_FAILURE);
    }
    return msqid;
}

/*
 * destroyMsgQueue:
 *   Removes the message queue.
 */
void destroyMsgQueue(int msqid) {
    if (msgctl(msqid, IPC_RMID, NULL) == -1) {
        perror("msgctl(IPC_RMID) failed");
        exit(EXIT_FAILURE);
    }
}

/*
 * sendMsg:
 *   Sends a Message on the queue. Returns 0 on success, -1 on failure.
 */
int sendMsg(int msqid, Message* msg) {
    if (msgsnd(msqid, msg, sizeof(Message) - sizeof(long), 0) == -1) {
        perror("msgsnd failed");
        return -1;
    }
    return 0;
}

/*
 * recvMsg:
 *   Receives a Message of given type and flag. Returns 0 on success, -1 on failure.
 */
int recvMsg(int msqid, Message* msg, long type, int flag) {
    if (msgrcv(msqid, msg, sizeof(Message) - sizeof(long), type, flag) == -1) {
        return -1;
    }
    return 0;
}