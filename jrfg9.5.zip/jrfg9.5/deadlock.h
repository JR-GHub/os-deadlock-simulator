#ifndef DEADLOCK_H
#define DEADLOCK_H

#include "resource.h"
#include "process_table.h"

int detectDeadlock(ResourceDescriptor resources[MAX_RESOURCES], PCB table[MAX_PROCESSES], int* deadlocked);
int resolveDeadlock(ResourceDescriptor resources[MAX_RESOURCES], PCB table[MAX_PROCESSES], int* deadlocked, int count);

#endif