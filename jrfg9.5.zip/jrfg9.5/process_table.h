#ifndef PROCESS_TABLE_H
#define PROCESS_TABLE_H

#include <sys/types.h>
#include "config.h"

typedef struct {
    int occupied;
    pid_t pid;
    int totalAllocated[MAX_RESOURCES];
    int totalRequested[MAX_RESOURCES];
} PCB;

void initProcessTable(PCB table[MAX_PROCESSES]);
int getAvailableIndex(PCB table[MAX_PROCESSES]);
int findPCBIndexByPID(PCB table[MAX_PROCESSES], pid_t pid);

#endif