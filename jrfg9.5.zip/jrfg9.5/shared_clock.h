#ifndef SHARED_CLOCK_H
#define SHARED_CLOCK_H

typedef struct {
    unsigned int seconds;
    unsigned int nanoseconds;
} SharedClock;

int createClock();
SharedClock* attachClock();
void incrementClock(SharedClock* clk, unsigned int ns);
void detachClock(SharedClock* clk);
void destroyClock();

#endif