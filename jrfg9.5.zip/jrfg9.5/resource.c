#include "resource.h"
#include "config.h"
#include <string.h>

void initResources(ResourceDescriptor resources[MAX_RESOURCES]) {
    for (int i = 0; i < MAX_RESOURCES; i++) {
        resources[i].total      = MAX_INSTANCES;
        resources[i].available  = MAX_INSTANCES;
        memset(resources[i].allocation, 0, sizeof(int)*MAX_PROCESSES);
        memset(resources[i].request,    0, sizeof(int)*MAX_PROCESSES);
        resources[i].queueSize = 0;
    }
}

int canGrant(int pid, int resIndex, int amount, ResourceDescriptor resources[]) {
    return amount <= resources[resIndex].available
        && resources[resIndex].allocation[pid] + resources[resIndex].request[pid] + amount
           <= resources[resIndex].total;
}

void grantResource(int pid, int resIndex, int amount, ResourceDescriptor resources[]) {
    resources[resIndex].available      -= amount;
    resources[resIndex].allocation[pid] += amount;
    resources[resIndex].request[pid]    = 0;

    // remove pid from wait queue
    int wq[MAX_QUEUE], nq = 0;
    for (int i = 0; i < resources[resIndex].queueSize; i++)
        if (resources[resIndex].waitQueue[i] != pid)
            wq[nq++] = resources[resIndex].waitQueue[i];

    memcpy(resources[resIndex].waitQueue, wq, sizeof(int)*nq);
    resources[resIndex].queueSize = nq;
}

void releaseResource(int pid, int resIndex, int amount, ResourceDescriptor resources[]) {
    if (resources[resIndex].allocation[pid] >= amount) {
        resources[resIndex].allocation[pid] -= amount;
        resources[resIndex].available      += amount;
    }
    resources[resIndex].request[pid] = 0;
}

void releaseAllResources(int pid, ResourceDescriptor resources[]) {
    for (int i = 0; i < MAX_RESOURCES; i++) {
        int amt = resources[i].allocation[pid];
        if (amt > 0) {
            resources[i].available      += amt;
            resources[i].allocation[pid] = 0;
        }
        resources[i].request[pid] = 0;

        // remove pid from wait queue
        int wq[MAX_QUEUE], nq = 0;
        for (int j = 0; j < resources[i].queueSize; j++)
            if (resources[i].waitQueue[j] != pid)
                wq[nq++] = resources[i].waitQueue[j];

        memcpy(resources[i].waitQueue, wq, sizeof(int)*nq);
        resources[i].queueSize = nq;
    }
}