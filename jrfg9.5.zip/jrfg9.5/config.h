#ifndef CONFIG_H
#define CONFIG_H

#define MAX_PROCESSES 18        // Max concurrent user processes
#define MAX_TOTAL_PROCESSES 40  // Max user processes generated
#define MAX_RESOURCES 5         // Number of resource types
#define MAX_INSTANCES 10        // Instances per resource
#define MAX_QUEUE 20            // Max blocked processes per resource
#define BILLION 1000000000

#define VERBOSE 1               // Toggle detailed logging
#define MAX_LOG_LINES 10000     // Limit log lines

#define MSGKEY 0x1234           // Message queue key
#define SHMKEY_CLOCK 0x5678     // Shared memory key for clock
#define SHMKEY_RES 0x5679       // Shared memory key for resources
#define SHMKEY_TABLE 0x5680     // Shared memory key for process table

#endif