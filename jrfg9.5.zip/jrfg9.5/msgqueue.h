// msgqueue.h
#ifndef MSGQUEUE_H
#define MSGQUEUE_H

#include <sys/ipc.h>
#include <sys/msg.h>
#include "token.h"

int createMsgQueue();
void destroyMsgQueue(int msqid);
int sendMsg(int msqid, Message* msg);
int recvMsg(int msqid, Message* msg, long type, int flag);

#endif