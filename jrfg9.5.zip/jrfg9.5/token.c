#include "token.h"
#include <stdio.h>

void initMessage(Message* msg, long mtype, int op, int resourceID, int amount, pid_t pid) {
    msg->mtype      = mtype;
    msg->op         = op;
    msg->resourceID = resourceID;
    msg->amount     = amount;
    msg->pid        = pid;
}

void printMessage(const Message* msg) {
    printf("Message: mtype=%ld op=%d res=%d amt=%d pid=%d\n",
           msg->mtype, msg->op, msg->resourceID, msg->amount, msg->pid);
}